

var ObjectID = require('mongodb').ObjectID;
// var moment = require('moment');

function Negocio (){



    this._id = null,
    this.identificador = "",

    this.tipoNegocio = "",
    this.nombreComercial = "",
    this.razonSocial = "",
    this.ruc = "",

    this.telefonoNegocio = "",
    this.direccionNegocio = "",
    this.nombreRepresentante = 0,
    this.telefonoRepresentante = "",
    this.cedulaRepresentante = "",

    this.fechaCreacion = null,
    this.usuarioCreacion = "",
    this.dataBase = "",
    this.estado = "",



// seteos y cambios de datos y parametros de factura standard
        this.setParameters= function (parametro, variable) {
            if(variable!=null)
                switch (parametro)
                {
                    case 'fechaCreacion':
                        var fecha = new Date(variable);
                        this.fechaCreacion = fecha;
                        break;
                    case 'usuarioCreacion':
                        this.usuarioCreacion = variable;
                        break;
                    case 'dataBase':
                        this.dataBase = variable;
                        break;
                    case 'identificador':
                        this.identificador = variable;
                        break;
                    //////////////////////////////////////////////////////////////

                    case 'tipoNegocio':
                        this.tipoNegocio = variable;
                        break;
                    case 'nombreComercial':
                        this.nombreComercial = variable;
                        break;
                    case 'razonSocial':
                        this.razonSocial = variable;
                        break;
                    case 'ruc':
                        this.ruc = variable;
                        break;
                    case 'telefonoNegocio':
                        this.telefonoNegocio = variable;
                        break;
                    case 'direccionNegocio':
                        this.direccionNegocio = variable;
                        break;
                    case 'nombreRepresentante':
                        this.nombreRepresentante = variable;
                        break;
                    case 'telefonoRepresentante':
                        this.telefonoRepresentante = variable;
                        break;
                    case 'cedulaRepresentante':
                        this.cedulaRepresentante = variable;
                        break;
                    //////////////////////////////////////////////////////////////

                    case 'estado':
                        this.estado = variable;
                        break;
                }
        };
}


module.exports = Negocio;
