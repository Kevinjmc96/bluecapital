'use strict'

var express = require('express');
var RegistroController = require('../controllers/registro');
var router = express.Router();

// var multipart = require('connect-multiparty');

// var md_auth = require('../middleware/authenticated');

router.get('/status', RegistroController.status);
router.patch('/registro', RegistroController.nuevoRegistro);
router.get('/verificacionUsuario', RegistroController.verificacionRegistro);

router.patch('/newPass', RegistroController.cambioContraseña);


module.exports = router;








