var digitos = [];
var resultado = [];
var coeficientes = [];
var coeficientes1=[2, 1, 2, 1, 2, 1, 2, 1, 2];
var coeficientes2=[3, 2, 7, 6, 5, 4, 3, 2, 0];
var coeficientes3=[4, 3, 2, 7, 6, 5, 4, 3, 2];
var provincias=["Azuay", "Bolivar", "Cañar", "Carchi", "Cotopaxi", "Chimborazo", "El Oro", "Esmeraldas",
    "Guayas", "Imbabura", "Loja", "Los Rios", "Manabi", "Morona Santiago", "Napo", "Pastaza", "Pichincha",
    "Tungurahua", "Zamora Chinchipe", "Galapagos", "Sucumbios", "Orellana", "Santo Domingo", "Santa Elena"];
var cedula = 1803315124;
var numero;
var aux;
var suma;
var caso;
console.log(cedula);
numero=cedula;
for(let i=1; i<=9; i=i+1){
    digitos[10-i]=numero%10;
    numero=numero/10;
    numero=numero-(digitos[10-i]/10);
}
digitos[0]=numero;
console.log(digitos);
switch (digitos[2]){
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
        caso = 1;
        coeficientes = coeficientes1;
        break;
    case 6:
        caso = 2;
        coeficientes = coeficientes2;
        break;
    case 9:
        caso = 3;
        coeficientes = coeficientes3;
        break;
    default:
        console.log('Numero invalido');
        break;
    }

for(let i=1; i<=9; i=i+1){
    aux=(coeficientes[i-1])*(digitos[i-1]);
    if((aux >= 10)&(caso == 1)){
        aux=aux-9;
    }
    resultado[i-1]=aux;
}
suma=0;
for(let i=1; i<=9; i=i+1){
    suma=suma+resultado[i-1];
}
switch (caso){
    case 1:
        aux=suma%10;
        aux=10-aux;
        if((aux==digitos[9])|((digitos[9]==0)&(aux==10))){
            console.log('Cedula verdadera');
            aux=digitos[0]*10+digitos[1];
            console.log(provincias[aux-1]);
        }
        else{    console.log('Cedula falsa');
        }
        break;
    case 2:
        aux=suma%11;
        aux=11-aux;
        if((aux==digitos[8])|((digitos[8]==0)&(aux==11))){
            console.log('Institucion publica verdadera');
            aux=digitos[0]*10+digitos[1];
            console.log(provincias[aux-1]);
        }
        else{    console.log('Institucion publica falsa');
        }
        break;
    case 3:
        aux=suma%11;
        aux=11-aux;
        if((aux==digitos[9])|((digitos[9]==0)&(aux==11))){
            console.log('Persona juridica verdadera');
            aux=digitos[0]*10+digitos[1];
            console.log(provincias[aux-1]);
        }
        else{    console.log('Persona juridica falsa');
        }
        break;
    default:
        break;
}
