'use strict'

var verificacionCedula = require('./funciones/verificacion_cedula');
// var FacturaElectronica = require('../models/facturaElectronica');
var mod_auth = require('../middleware/moduleAuthorization');
var global = require('../global');
var db = require('../db');
const ObjectID = require('mongodb').ObjectID;
const bcrypt = require('bcryptjs');
const fetch = require('node-fetch');


function status (req,res) {
    return res.status(200).send('Ok')
}

////////////////////////////////////////////////////////////////CREAR NUEVO USUARIO
function nuevoRegistro (req, res){

    // verificacion de parametros en mensaje
    if (req.body.nombre=== undefined || req.body.password=== undefined || req.body.email=== undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }
    
    let busqueda ;
        
    busqueda = req.body.email;
    //console.log('busqueda', busqueda);

    _busquedaUsuarioEmail(busqueda).then(result => {
        if (result === null) {
            creacion_cuenta(req, res);
        } else {
            if(result.estado === 'validado' ) {
                return res.status(202).send({mensaje:'cuenta ya validada'});
            }
            return res.status(202).send({mensaje:'cuenta encontrada pendiente de validacion'});
        }

    }, reason => {
        console.log('error', reason);
        return res.status(500).send({mensaje:'error en busqueda'});
    });
}

async function creacion_cuenta (req, res){
        creacionUsuario(req, res);
}

async function creacionUsuario(req, res) {

    const fechaActual = new Date();
    fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );
    const codigoVerificacion = await (generadorNumeroRandom(5));
    const claveCifrada = await generadorClave(req.body.password);
    const identificador = req.body.email+'-'+codigoVerificacion; 
    
    let usuario = {
        identificadorUsuario : identificador,
        nombreCompleto: req.body.nombre,
        email: req.body.email,
        fechaCreacion: fechaActual,
        codigoVerificacion: codigoVerificacion,
        estado: "pendiente",
        password: claveCifrada,
        tipoCuenta: req.body.tipoCuenta,
    };

    var collection = db.get().db(global.getAuthDatabase()).collection('usuarios');

    collection.insertOne(usuario,(err) => {
        if (err) {
            return res.status(500).send({mensaje: "Error en la creación del usuario"});
        } else {
            let promesaGeneral = new Promise((resolve,reject) => {resolve ('start')})
            promesaGeneral.then(
                result =>{

///////////////////////////////////////////////////////////////////////////////////////
            
                    let email_nombre= usuario.nombreCompleto;
                    let email_email ="info@blucapital.ec";
                    let email_URL= "http://54.70.216.182:45100/verificacionUsuario?id="+ usuario.identificadorUsuario+"&cdg="+ usuario.codigoVerificacion ;
                    //let email_URL = "http://localhost:45100/verificacionUsuario?id="+ usuario.identificadorUsuario+"&cdg="+ usuario.codigoVerificacion ;

                    let mensaje= "<div style=\"display: block; width: 100%; justify-content: center; align-items: center; font-family: 'Roboto', sans-serif;\">  <div style=\"margin-left: 25%; margin-right: 25%; align-items: center; text-align: center; border-bottom: 2px solid #D9D9D9; padding-bottom: 40px;\"><div><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/logo-1.svg\" alt=\"\" style=\"display: block; height: 42px; margin-top: 40px; margin: auto;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/logo-2.svg\" alt=\"\" style=\"display: block; height: 138px; margin-top: 40px; margin: auto;\"></div><div style=\"font-size: 24px; font-weight: bold; margin-top: 20px; color: #444444;\">¡Felicidades <span>"+ email_nombre +"</span>! te damos la bienvenida al fondo de inversiones Blue Capital</div><div style=\"margin-top: 20px; font-size: 18px;\"> Estás a punto de activar tu cuenta, haz click en el siguiente botón para disfrutar todos los beneficios de nuestra plataforma digital de inversiones.</div><div class=\"call-to-action\" style=\"margin-top: 20px; margin-left: 30%; margin-right: 30%; background-color: #2A5CA6; padding: 10px 5px; cursor: pointer; border-radius: 10px;\"><a href=\""+email_URL+"\" style=\"color: white; text-decoration: none; font-weight: bold;\">Validar cuenta</a></div></div><div style=\"margin-left: 20%; margin-right: 20%; text-align: center; color: #A6A6A6;\"><p style=\"font-size: 14px;\">Este mensaje ha sido enviado de forma automática para el registro de cuenta de Blue Capital, no respondas este mensaje. Para más información envía un mensaje a <span>"+email_email+" </span> </p><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/blue-icon.svg\" alt=\"\" style=\"width: 86px; height: 86px\"><div style=\"margin-top: 20px;\"><a href=\"https://twitter.com/home\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/twitter.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://instagram.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/instagram.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.facebook.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/facebook.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.youtube.com/\" style=\"margin-left: 10px; margin-right: 10px; width: 40px; height: 40px\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/youtube.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a></div><p style=\"font-size: 20px;\">Blue Capital - 2021</p></div></div>";
///////////////////////////////////////////////////////////////////////////////////////
                    return enviar_email("Blue Capital - Validación de cuenta", "Blue Capital", usuario.email, mensaje)
                },error=>{
                    return  Promise.reject(error)
                }
            )
            .then(
                mail =>{
                    return res.status(200).send({mensaje: 'Usuario creado', mensajeAdicional: 'Se ha enviado el codigo de verificacion al correo: '+mail});
                },error=>{
                    return  Promise.reject(error)
                }
            )       
        }
    });
}

function enviar_email (titulo, de, mail, mensaje){

    const promesa = new Promise((resolve, reject) => {

        var URL= 'https://api.ushops.tech/EgmSystems/emailing/gmail/sendEmail';
        var request = {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "titulo": titulo,
                "de": de,
                "email":  mail,
                "mensaje": mensaje,
            }),
            cache: 'no-cache'
            
        };

        fetch(URL,request)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            resolve (mail)
        })
        .catch(function(err) {
            reject (err);
        });    
    })
    return promesa;
}

////////////////////////////////////////////////////////////////VERIFICACION DE REGISTRO
function verificacionRegistro (req, res){

    //validacion
    //http://localhost:45100/verificacionUsuario?id=kj.mc@hotmail.com-14637&cdg=14637

    let user = req.query;
    console.log(user);


    // verificacion de parametros en mensaje
    if ((user.id=== undefined) ||  user.cdg === undefined) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    let busqueda ;

    busqueda = req.query.id;
    console.log('busqueda', busqueda);

      
        _busquedaUsuarioEmail(busqueda).then(async result => {

            console.log('result', result);
            if(result === null ) {
                return res.status(500).send({mensaje:'cuenta inexistente'});
            }
            if(result.estado === 'pendiente') {
                // validacion primera vez cuenta
                console.log(result.codigoVerificacion , req.query.cdg);
                if (result.codigoVerificacion === req.query.cdg) {

                    let actualizacionCuenta = {
                        estado: 'validado',
                    };

                    var collection = db.get().db(global.getAuthDatabase()).collection('usuarios');
                    
                    collection.findOneAndUpdate( {_id: new ObjectID(result._id)}, {$set: actualizacionCuenta}, (err,resultdb)=> {
                        
                        if (err) {
                            return res.status(500).json({error: err.message});
                        }
                        
                        if (!resultdb.value) {
                            return res.status(404).json({error: 'no actualizado'});
                        }
///////////////////////////////////////////////////////////////////////////////////////

                        let email_nombre= result.nombreCompleto;
                        let email_email ="info@blucapital.ec";
                        let email_login= "https://www.bluecapital.com.tr/en/";

                        let mensaje= "<div style=\"display: block; width: 100%; justify-content: center; align-items: center; font-family: 'Roboto', sans-serif;\">  <div style=\"margin-left: 25%; margin-right: 25%; align-items: center; text-align: center; border-bottom: 2px solid #D9D9D9; padding-bottom: 40px;\"><div><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/logo-1.svg\" alt=\"\" style=\"display: block; height: 42px; margin-top: 40px; margin: auto;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/logo-2.svg\" alt=\"\" style=\"display: block; height: 138px; margin-top: 40px; margin: auto;\"></div><div style=\"font-size: 24px; font-weight: bold; margin-top: 20px; color: #444444;\">¡Felicidades <span>"+ email_nombre +"</span>! te damos la bienvenida al fondo de inversiones Blue Capital</div><div style=\"margin-top: 20px; font-size: 18px;\"> Tu cuenta en la plataforma digitital de inversiones Blue Capital ha sido cerada. Puedes iniciar sesión a través del siguiente botón.</div><div class=\"call-to-action\" style=\"margin-top: 20px; margin-left: 30%; margin-right: 30%; background-color: #2A5CA6; padding: 10px 5px; cursor: pointer; border-radius: 10px;\"><a href=\""+email_login+"\" style=\"color: white; text-decoration: none; font-weight: bold;\">Iniciar sesión</a></div></div><div style=\"margin-left: 20%; margin-right: 20%; text-align: center; color: #A6A6A6;\"><p style=\"font-size: 14px;\">Este mensaje ha sido enviado de forma automática para el registro de cuenta de Blue Capital, no respondas este mensaje. Para más información envía un mensaje a <span>"+email_email+" </span> </p><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/blue-icon.svg\" alt=\"\" style=\"width: 86px; height: 86px\"><div style=\"margin-top: 20px;\"><a href=\"https://twitter.com/home\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/twitter.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://instagram.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/instagram.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.facebook.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/facebook.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.youtube.com/\" style=\"margin-left: 10px; margin-right: 10px; width: 40px; height: 40px\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/youtube.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a></div><p style=\"font-size: 20px;\">Blue Capital - 2021</p></div></div>";

                        return res.status(200).send(mensaje);
///////////////////////////////////////////////////////////////////////////////////////
                        //return res.status(200).send({mensaje: 'validado correctamente'});
                    });

                } else {
                    return res.status(500).send({mensaje:'codigo incorrecto'});
                }
            } else {
                return res.status(500).send({mensaje:'validacion incorrecta'});
            }
        }, reason => {
            // si el usuario ya esta registrado entrega el error
            console.log('error', reason);
            return res.status(500).send({mensaje:'error en busqueda'});
        });

}

////////////////////////////////////////////////////////////////CAMBIO DE CONTRASEñA
function cambioContraseña (req, res){
    
    let user = req.body;
    console.log(user);

    if ( req.body.correo === undefined || req.body.contrasenaAnterior === undefined || req.body.contrasenaNueva === undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }
    let busquedaUsuario = req.body.correo;

    _busquedaUsuarioEmail(busquedaUsuario).then( async result  =>  {

        if (result.estado !== 'validado') {
            return res.status(500).send({message: "Error de estado"});
        }

        if (!bcrypt.compareSync(req.body.contrasenaAnterior, result.password)){
            return res.status(401).send({error: "Password incorrecto"});
        }
        
        if (req.body.contrasenaNueva.length >= 6){

            const claveCifrada = await generadorClave(req.body.contrasenaNueva);

            let auxActualizacion ={};
            auxActualizacion.password=  claveCifrada;
        
            var collection = db.get().db(global.getAuthDatabase()).collection('usuarios');

            collection.findOneAndUpdate({_id: new ObjectID(result._id)}, {$set:auxActualizacion}, (err,result)=> {
                if (err) {
                    return res.status(500).json({error: err.message});
                }
                if (!result.value) {
                    return res.status(404).json({error: 'No actualizado'});
                }
                return res.status(200).send({mensaje: 'Cambio de clave realizada con exito'});
            });
    
        } else {
            return res.status(500).send({mensaje:'Password debil'});
        }
    });
    
}

////////////////////////////////////////////////////////////////OLVIDE CONTRASEñA PARTE 1
function olvideContraseña_P1 (req, res){
    
    let usuario = req.body.correo;
    let peticion= req.body.peticion;

    console.log("0 ",usuario, peticion);

    if ( usuario === undefined || peticion === undefined || peticion !== "reinicio" ) {
        return res.status(500).send({message: "Error de usuario"});
    }

    _busquedaUsuarioEmail(usuario)
        .then( async result  =>  {

            if(result === null ) {
                return res.status(500).send({mensaje:'cuenta inexistente'});
            }

            if (result.estado !== 'validado') {
                return res.status(500).send({message: "Error de estado"});
            }

            let email_email ="info@blucapital.ec";
            let email_URL= "http://54.70.216.182:45100/reset?email="+ result.email+"&cdg="+ result.codigoVerificacion  ;
            //let email_URL= "http://localhost:45100/reset?email="+ result.email+"&cdg="+ result.codigoVerificacion  ;

            let mensaje= "<div style=\"display: block; width: 100%; justify-content: center; align-items: center; font-family: 'Roboto', sans-serif;\">  <div style=\"margin-left: 25%; margin-right: 25%; align-items: center; text-align: center; border-bottom: 2px solid #D9D9D9; padding-bottom: 40px;\"><div><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/logo-1.svg\" alt=\"\" style=\"display: block; height: 42px; margin-top: 40px; margin: auto;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/logo-2.svg\" alt=\"\" style=\"display: block; height: 138px; margin-top: 40px; margin: auto;\"></div><div style=\"font-size: 24px; font-weight: bold; margin-top: 20px; color: #444444;\">Restablecimiento de contraseña</div><div style=\"margin-top: 20px; font-size: 18px;\">Se ha registrado una solicitud de recuperación de contraseña. Para recuperar tu contraseña debes hacer click en el siguiente botón. Si no has solicitado la recuperación de tu contraseña ignora este mensaje.</div><div class=\"call-to-action\" style=\"margin-top: 20px; margin-left: 30%; margin-right: 30%; background-color: #2A5CA6; padding: 10px 5px; cursor: pointer; border-radius: 10px;\"><a href=\""+email_URL+"\" style=\"color: white; text-decoration: none; font-weight: bold;\">Recuperar contraseña</a></div></div><div style=\"margin-left: 20%; margin-right: 20%; text-align: center; color: #A6A6A6;\"><p style=\"font-size: 14px;\">Este mensaje ha sido enviado de forma automática para el registro de cuenta de Blue Capital, no respondas este mensaje. Para más información envía un mensaje a <span>"+email_email+" </span> </p><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/blue-icon.svg\" alt=\"\" style=\"width: 86px; height: 86px\"><div style=\"margin-top: 20px;\"><a href=\"https://twitter.com/home\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/twitter.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://instagram.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/instagram.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.facebook.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/facebook.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.youtube.com/\" style=\"margin-left: 10px; margin-right: 10px; width: 40px; height: 40px\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/youtube.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a></div><p style=\"font-size: 20px;\">Blue Capital - 2021</p></div></div>";
            return enviar_email("Blue Capital - Restablecimiento de contraseña", "Blue Capital", result.email, mensaje)
             
        .then(
            mail =>{
                return res.status(200).send({mensaje: 'Se ha enviado el codigo de verificacion al correo: '+mail});
            },error=>{
                return  Promise.reject(error)
            }
        )  
    });
    
}

function olvideContraseña_P2 (req, res){    

    let usuario = req.query.email;
    let codigo = req.query.cdg;

    console.log('2', usuario, codigo);

    if ( usuario === undefined || codigo === undefined ) {
        return res.status(500).send({message: "Error de usuario"});
    }

    _busquedaUsuarioEmail(usuario)
        .then( async result  =>  {

            if(result === null ) {
                return res.status(500).send({mensaje:'cuenta inexistente'});
            }

            if (result.estado !== 'validado') {
                return res.status(500).send({message: "Error de estado"});
            }

            if (result.codigoVerificacion !== codigo) {
                return res.status(500).send({message: "Error de codigo"});
            }
            
            console.log(result)
            
            const codigoVerificacion = await (generadorNumeroRandom(5));
            const claveCifrada = await generadorClave(codigoVerificacion);
            
            let update = {
                codigoVerificacion: codigoVerificacion,
                password: claveCifrada,
            };

            console.log('asd ',update)
            

            return _actualizarDatos(usuario, update)
             
        .then(
            result =>{
                let email_usuario= result.usuario;
                let email_codigo= result.codigo;
                let email_email ="info@blucapital.ec" ;
                let email_URL= "https://www.youtube.com/" ;

                let mensaje= "<div style=\"display: block; width: 100%; justify-content: center; align-items: center; font-family: 'Roboto', sans-serif;\"><div style=\"margin-left: 25%; margin-right: 25%; align-items: center; text-align: left; border-bottom: 2px solid #D9D9D9; padding-bottom: 40px;\"><div><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/logo-1.svg\" alt=\"\" style=\"display: block; height: 42px; margin-top: 40px; margin: auto;\"></div><div style=\"font-size: 24px; font-weight: bold; margin-top: 20px; color: #444444; text-align: center;\">Contraseña restablecida</div><div style=\"margin-top: 20px; font-size: 18px;\">Se ha realizado el cambio de contraseña de tu cuenta de Blue Capital <span style=\"color: #2481d7;\"> "+email_usuario+" </span> </div><div style=\"margin-top: 20px; font-size: 18px;\">Utiliza este codigo código para ingresar a tu cuenta: </div><div style=\"margin-top: 20px; font-size: 27px; text-align: center; font-weight: bold;\"> "+email_codigo+" </div><div style=\"margin-top: 20px; font-size: 18px;\">¿No has sido tú?, asegúrate de cambiar tu contraseña.</div><div style=\"margin-top: 20px; font-size: 18px;\">Gracias, <br> Equipo de Blue Capital</div></div><div style=\"margin-left: 20%; margin-right: 20%; text-align: center; color: #A6A6A6;\"><p style=\"font-size: 14px;\">Este mensaje ha sido enviado de forma automática para el cambio de contraseña, no respondas este mensaje. Para más información envía un mensaje a <span> "+email_email+" </span> </p><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/blue-icon.svg\" alt=\"\" style=\"width: 86px; height: 86px\"><div style=\"margin-top: 20px;\"><a href=\"https://twitter.com/home\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/twitter.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://instagram.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/instagram.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.facebook.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/facebook.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.youtube.com/\" style=\"margin-left: 10px; margin-right: 10px; width: 40px; height: 40px\"><img src=\"https://s3-us-west-2.amazonaws.com/blue.capital-repository/correo/youtube.svg\" alt=\"\" style=\"width: 40px; height: 40px\"></a></div><p style=\"font-size: 20px;\">Blue Capital - 2021</p></div></div>";
                return res.status(200).send(mensaje);
            },error=>{
                return  Promise.reject(error)
            }
        )  
    });
    
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function _busquedaUsuarioEmail(parametro){

    var collection = db.get().db(global.getAuthDatabase()).collection('usuarios');

    var search= {$or: [{email: parametro},{identificadorUsuario: parametro},{cedula: parametro}]};

    const promesa = new Promise((resolve, reject) => {

        collection.findOne(search, function (err,result) {
            if(err){
                reject({mensaje:"Error en la peticion del usuario"});                
            }
                resolve(result);
            });
    });
    return promesa;
}

function _actualizarDatos(usuario, update){
    
    var collection = db.get().db(global.getAuthDatabase()).collection('usuarios');

    var search= {email: usuario};

    const promesa = new Promise((resolve, reject) => {

        collection.findOneAndUpdate(search, {$set: update}, function (err,result) {
            if(err){
                reject ({message:"Error al actualizar"});
            }else{
                if(result.value == null){
                    reject ({message:"No existe el usuario"});
                }else{ 
                    let aux ={
                        usuario: usuario,
                        codigo: update.codigoVerificacion,
                    }
                    console.log('aux ', aux)
                    resolve (aux)  
                        
                }
            }
        });

    });
    return promesa;
}
////////////////////////////////////////////////////////////////FUNCIONES GENERALES

function generadorNumeroRandom (digitos){
    let caracteres = "0123456789";
    let identificador = "";
    let i;
    for (i=0; i<digitos; i++) identificador +=caracteres.charAt(Math.floor(Math.random()*caracteres.length));

    return identificador;
}

function generadorClave(clave){
    var salt = bcrypt.genSaltSync(13);
    var hasht;

    const promesa = new Promise((resolve, reject) => {
        bcrypt.hash(clave, salt, function(err, hash){
            if(err) throw err;

            bcrypt.compare(clave, hash, function(err, result) {
                if (err) {
                    throw (err);
                }
                console.log(result);
                hasht = hash;
                resolve(hasht);
            });
        });

    });
    return promesa;

}

module.exports = {
    status,
    nuevoRegistro,
    verificacionRegistro,
    cambioContraseña,
    olvideContraseña_P1,
    olvideContraseña_P2
};

