'use strict'

var verificacionCedula = require('./funciones/verificacion_cedula');
// var FacturaElectronica = require('../models/facturaElectronica');
var mod_auth = require('../middleware/moduleAuthorization');
var global = require('../global');
var db = require('../db');
const ObjectID = require('mongodb').ObjectID;
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fetch = require('node-fetch');

function status (req,res) {
    return res.status(200).send('controlador registro OK');
}

function nuevoRegistro (req, res){
    let user = req.body;
    //console.log(user);

    // verificacion de parametros en mensaje
    if (req.body.nombre=== undefined || req.body.password=== undefined) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    // if (req.body.cedula=== undefined  && req.body.username=== undefined ) {
    if (req.body.email=== undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }
    
    let busqueda ;
        
    busqueda = req.body.email;
    //console.log('busqueda', busqueda);

    _busquedaUsuarioEmail(busqueda).then(result => {
        if (result === null) {
            creacion_cuenta(req, res);
        } else {
            if(result.estado === 'validado' ) {
                return res.status(202).send({mensaje:'cuenta ya validada'});
            }
            return res.status(202).send({mensaje:'cuenta encontrada pendiente de validacion'});
        }

    }, reason => {
        console.log('error', reason);
        return res.status(500).send({mensaje:'error en busqueda'});
    });
}

async function creacion_cuenta (req, res){
        creacionUsuario(req, res);
}

async function creacionUsuario(req, res) {

    const fechaActual = new Date();
    fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );
    const codigoVerificacion = await (generadorNumeroRandom(5));
    const claveCifrada = await generadorClave(req.body.password);
    const identificador = req.body.email+'-'+codigoVerificacion; 
    
    let usuario = {
        identificadorUsuario : identificador,
        nombreCompleto: req.body.nombre,
        email: req.body.email,
        fechaCreacion: fechaActual,
        codigoVerificacion: codigoVerificacion,
        estado: "pendiente",
        password: claveCifrada,
        
        //////////////// aqui debes colocar los parametros adicionales de creacion kevin ///////////////
        /*
        cedula: req.body.cedula,
        telefono: req.body.telefono,
        direccion: req.body.direccion,
        pais: req.body.pais,
        ciudad: req.body.ciudad,
        banco: req.body.banco,
        cuenta: req.body.cuenta,
        */
    };

    var collection = db.get().db(global.getAuthDatabase()).collection('usuarios');

    collection.insertOne(usuario,(err) => {
        if (err) {
            return res.status(500).send({mensaje: "Error en la creación del usuario"});
        } else {
            let promesaGeneral = new Promise((resolve,reject) => {resolve ('start')})
            promesaGeneral.then(
                result =>{

///////////////////////////////////////////////////////////////////////////////////////

                    //let validacionURL = "http://localhost:45100/verificacionUsuario?id="+ usuario.identificadorUsuario+"&cdg="+ usuario.codigoVerificacion ;
                    let emailBC ="email@bc.com";
                    let validacionURL= "http://54.70.216.182:45100/verificacionUsuario?id="+ usuario.identificadorUsuario+"&cdg="+ usuario.codigoVerificacion ;

                    let mensaje= "<div style=\"display: block; width: 100%; justify-content: center; align-items: center; font-family: 'Roboto', sans-serif;\"><div style=\"margin-left: 25%; margin-right: 25%; align-items: center; text-align: center; border-bottom: 2px solid #D9D9D9; padding-bottom: 40px;\"><div><img src=\"logo-1.svg\" alt=\"\" style=\"display: block; height: 42px; margin-top: 40px; margin: auto;\"><img src=\"logo-2.svg\" alt=\"\" style=\"display: block; height: 138px; margin-top: 40px; margin: auto;\"></div><div style=\"font-size: 24px; font-weight: bold; margin-top: 20px; color: #444444;\">¡Felicidades <span> "+usuario.nombreCompleto+" </span>! te damos la bienvenida al fondo de inversiones Blue Capital</div><div style=\"margin-top: 20px; font-size: 18px;\">Estás a punto de activar tu cuenta, haz click en el siguiente botón para disfrutar todos los beneficios de nuestra plataforma digital de inversiones</div><div class=\"call-to-action\" style=\"margin-top: 20px; margin-left: 25%; margin-right: 25%; background-color: #2A5CA6; padding: 10px 20px; cursor: pointer; border-radius: 10px;\"><a href=\" "+ validacionURL +" \" style=\"color: white; text-decoration: none; font-weight: bold;\">Activar cuenta</a></div></div><div style=\"margin-left: 20%; margin-right: 20%; text-align: center; color: #A6A6A6;\"><p style=\"font-size: 14px;\">Este mensaje ha sido enviado de forma automática para el registro de cuenta de Blue Capital, no respondas este mensaje. Para más información envía un mensaje a <span> "+emailBC+" </span> </p><img src=\"blue-icon.svg\" alt=\"\" style=\"width: 86px; height: 86px\"><div style=\"margin-top: 20px;\"><a href=\"https://twitter.com/home\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://www.vhv.rs/dpng/d/211-2110922_transparent-background-twitter-logo-hd-png-download.png\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://instagram.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Instagram-Icon.png/1025px-Instagram-Icon.png\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.facebook.com/\" style=\"margin-left: 10px; margin-right: 10px;\"><img src=\"https://iconape.com/wp-content/png_logo_vector/facebook-f-logo-2019.png\" alt=\"\" style=\"width: 40px; height: 40px\"></a><a href=\"https://www.youtube.com/\" style=\"margin-left: 10px; margin-right: 10px; width: 40px; height: 40px\"><img src=\"https://i.pinimg.com/originals/31/23/9a/31239a2f70e4f8e4e3263fafb00ace1c.png\" alt=\"\" style=\"width: 40px; height: 40px\"></a></div><p style=\"font-size: 20px;\">Blue Capital - 2021</p></div></div>";
///////////////////////////////////////////////////////////////////////////////////////
                    return enviar_email("Blue Capital - Codigo de validacion", "Blue Capital", usuario.email, mensaje)
                },error=>{
                    return  Promise.reject(error)
                }
            )
            .then(
                mail =>{
                    return res.status(200).send({mensaje: 'Usuario creado', mensajeAdicional: 'Se ha enviado el codigo de verificacion al correo: '+mail});
                },error=>{
                    return  Promise.reject(error)
                }
            )       
        }
    });
}

function enviar_email (titulo, de, mail, mensaje){

    const promesa = new Promise((resolve, reject) => {

        var URL= 'https://api.ushops.tech/EgmSystems/emailing/gmail/sendEmail';
        var request = {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "titulo": titulo,
                "de": de,
                "email":  mail,
                "mensaje": mensaje,
            }),
            cache: 'no-cache'
            
        };

        fetch(URL,request)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            resolve (mail)
        })
        .catch(function(err) {
            reject (err);
        });    
    })
    return promesa;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
function verificacionRegistro (req, res){

    //validacion
    //http://localhost:45100/verificacionUsuario?id=kj.mc@hotmail.com-14637&cdg=14637

    let user = req.query;
    console.log(user);


    // verificacion de parametros en mensaje
    if ((user.id=== undefined) ||  user.cdg === undefined) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }

    let busqueda ;

    busqueda = req.query.id;
    console.log('busqueda', busqueda);

      
        _busquedaUsuarioEmail(busqueda).then(async result => {

            console.log('result', result);
            if(result === null ) {
                return res.status(500).send({mensaje:'cuenta inexistente'});
            }
            if(result.estado === 'pendiente') {
                // validacion primera vez cuenta
                console.log(result.codigoVerificacion , req.query.cdg);
                if (result.codigoVerificacion === req.query.cdg) {

                    let actualizacionCuenta = {
                        estado: 'validado',
                    };

                    var collection = db.get().db(global.getAuthDatabase()).collection('usuarios');
                    
                    collection.findOneAndUpdate( {_id: new ObjectID(result._id)}, {$set: actualizacionCuenta}, (err,resultdb)=> {
                        
                        if (err) {
                            return res.status(500).json({error: err.message});
                        }
                        
                        if (!resultdb.value) {
                            return res.status(404).json({error: 'no actualizado'});
                        }
///////////////////////////////////////////////////////////////////////////////////////

                        let message_header_register = "<div style=\"padding: 20px;\"><div style=\"margin: 32px auto; display: flex; flex-direction: row; justify-content: center;\"><div style=\"margin: auto;\"><img  src=\"https://s3-us-west-2.amazonaws.com/pruebas.ushops/logotipo.jpg\" alt=\"\"></div></div><div style=\"margin: 0px auto; border-radius: 5px; border: none; background-color: rgb(237, 250, 248); max-width: 500px; padding: 25px 15px; font-size: 16px;\"><h1 style=\"font-size: 20px; text-align: center;\">Ya está listo tu Código de verificación</h1><p style=\"text-align: center; font-size: 16px;\">Una vez ingresado el código ya serás un usuario habilitado en uShopsMarketplace y podrás disfrutar de la mejor experiencia en compras</p></div><div style=\"max-width: 500px; margin: 0px auto;\"><p style=\"text-align: center; font-size: 14px;\">Tu código de verificación es:</p><h1 style=\"text-align: center; letter-spacing: 2px; font-size: 32px; font-weight: bold;\">";

                        return res.status(200).send(message_header_register);
///////////////////////////////////////////////////////////////////////////////////////
                        //return res.status(200).send({mensaje: 'validado correctamente'});
                    });

                } else {
                    return res.status(500).send({mensaje:'codigo incorrecto'});
                }
            } else {
                return res.status(500).send({mensaje:'validacion incorrecta'});
            }
        }, reason => {
            // si el usuario ya esta registrado entrega el error
            console.log('error', reason);
            return res.status(500).send({mensaje:'error en busqueda'});
        });

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function _busquedaUsuarioEmail(parametro){

    var collection = db.get().db(global.getAuthDatabase()).collection('usuarios');

    var search= {$or: [{email: parametro},{identificadorUsuario: parametro}]};

    const promesa = new Promise((resolve, reject) => {

        collection.findOne(search, function (err,result) {
            if(err){
                reject({mensaje:"Error en la peticion del usuario"});                
            }
                resolve(result);
            });
    });
    return promesa;
}

////////////////////////////////////////////////////////////////funciones de utilidad //////////////////////////////////

function generadorNumeroRandom (digitos){
    let caracteres = "0123456789";
    let identificador = "";
    let i;
    for (i=0; i<digitos; i++) identificador +=caracteres.charAt(Math.floor(Math.random()*caracteres.length));

    return identificador;
}

function generadorClave(clave){
    var salt = bcrypt.genSaltSync(13);
    var hasht;

    const promesa = new Promise((resolve, reject) => {
        bcrypt.hash(clave, salt, function(err, hash){
            if(err) throw err;

            bcrypt.compare(clave, hash, function(err, result) {
                if (err) {
                    throw (err);
                }
                console.log(result);
                hasht = hash;
                resolve(hasht);
            });
        });

    });
    return promesa;

}

module.exports = {
    status,
    nuevoRegistro,
    verificacionRegistro,
};

