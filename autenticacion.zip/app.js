'use strict'

var express = require('express');
var bodyParser = require('body-parser');

var app = express();


    var autenticacion_route = require('./routes/autenticacion');
    // var registro_route = require('./routes/registro');
const cors = require('cors');


//rutas

console.log('peticion entrante');

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
//
// //configuracion de cabeceras
app.use((req, res, next)=>{
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
    res.header('Access-Control-Allow-Methods', 'PATCH');
    res.header('Allow', 'PATCH');
    // res.header('Access-Control-Allow-Credentials', true);
    next();
});

// app.use(checkJwt({secret:global.JWT_SECRET,
//     credentialsRequired: true,
// }).unless({path:'/api/auth'}));


// app.use(function(req, res, next) {
//     if(req.url=='/api/auth')
//     {
//         // console.log('Autenticando');
//         next();
//     }
//     else {
//         let usernameRec = global.getUsername(req.headers);
//         let collection2 = conexion.db('Usuarios').collection('ListaConexiones');
//         collection2.findOne({username:usernameRec}, (err,cliente)=>{
//             if(err){return res.send(err);}
//             if(cliente.jwt== global.getToken(req.headers))
//             {
//                 // console.log('encontrado');
//                 next(); // pasa el control al siguiente manejador
//             }
//             else {
//                 // console.log('no encontrado');
//                 next();
//                 // res.status(401).json('error, salir');
//             }
//         });
//     }
//     // console.log('finalizado');
// });
// app.use(function(req,res,next){
//     // console.log('ok');
//     next();
// });
app.use(cors());
// app.use(fileUpload({
//     limits: { fileSize: 4 * 1024 * 1024 },
// }));
//
// app.use((err,req,res,next)=>{
//     if(err.name === 'UnauthorizedError'){
//         res.status(401).json({error:err.message});
//     }
// });


//rutas base
    app.use('', autenticacion_route);
    // app.use('', registro_route);





module.exports = app;







//
// app.use(checkJwt({secret:global.JWT_SECRET,
//     credentialsRequired: false,
//
//     //     getToken: function fromHeaderOrQuerystring (req) {
//     //     if (req.headers.authorization && req.headers.authorization.split(' ')[0] === 'Bearer') {
//     //         return req.headers.authorization.split(' ')[1];
//     //     } else if (req.query && req.query.token) {
//     //         return req.query.token;
//     //     }
//     //     return null;
//     // }
// //          function(req, res) {
// // //             if (!req.user.admin)
// //                  return res.sendStatus(401);
// // //             res.sendStatus(200);
// //          }
// }).unless({path:'/api/auth'}));