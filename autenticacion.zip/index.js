'use strict'

var port =  45101; //process.env.PORT ||
const version = "v1.0"; //


var db = require('./db');
var app = require('./app');




// Connect to Mongo on start
// db.connect('mongodb://127.0.0.1:27017/admin', function(err) {
// db.connect('mongodb://dbClickAdmin:clickAdminPass@10.0.0.194:38510/admin', function(err) {
// db.connect('mongodb://dbClickAdmin:clickAdminPass@127.0.0.1:38510/admin', function(err) {
db.connect('mongodb://dbClickAdmin:clickAdminPass@52.43.113.195:38510/admin', function(err) {

// db.connect('mongodb://egmAdmin:passEgm123@10.0.1.45:49850/admin', function(err) {
    if (err) {
        return console.log(err)
    } else {
        console.log("La base de datos se conecta correctamente");



        app.listen(port, function(){
            console.log("Servidor del api rest "+version+ " de sistema en:"+port);
        })
    }
});
