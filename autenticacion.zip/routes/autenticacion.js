'use strict'



var express = require('express');
var AutenticacionController = require('../controllers/autenticacion');
var router = express.Router();

// var multipart = require('connect-multiparty');

// var md_auth = require('../middleware/authenticated');

    router.get('/status', AutenticacionController.status);

    // router.get('/facturacion/getAllBills', FacturacionController.getAllBills);

    // router.patch('/autenticacion/auth', AutenticacionController.auth);
    router.patch('/getAuth', AutenticacionController.auth);

    // router.patch('/getAuthMob', AutenticacionController.administracionAuthMob);

    router.patch('/registroFirebaseID', AutenticacionController.registroFirebaseId);


    router.patch('/verifyRefreshToken', AutenticacionController.verifyRefreshToken);


    router.patch('/changePass', AutenticacionController.cambioContraseña);

    

    // router.patch('/setNewPassUsrMob', AutenticacionController.setNewPassUsrMob);

// router.patch('/testUsrMob', AutenticacionController.testAuthMob);

    // router.patch('/getUsrIm', AutenticacionController.administracionAuthIm);
    // router.patch('/autenticacion/getNegocios', NegocioController.getNegocios);
    // router.put('/facturacion/updateBill', FacturacionController.updateBill);


    // router.get('/facturacion/getTotalBills', FacturacionController.getTotalBills);

    // router.get('/facturacion/getBillsByDate', FacturacionController.getBillsByDate);





module.exports = router;







