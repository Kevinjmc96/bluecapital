'use strict'

// var Negocio = require('../models/negocio');
// var FacturaElectronica = require('../models/facturaElectronica');
var mod_auth = require('../middleware/moduleAuthorization');
var global = require('../global');
var db = require('../db');
const ObjectID = require('mongodb').ObjectID;
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

function status (req,res) {

    return res.status(200).send('controlador autenticacion OK');
}

function auth (req, res){
    let user = req.body;
    console.log(user);

    if ((req.body.username=== undefined) ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }
    
    let busquedaUsuario = req.body.username;
    // let busquedaScope =req.body.scope;


            _busquedaUsuarioAdmin(busquedaUsuario).then(result => {
                console.log('ok', result);

////////////////////////////////////////////////////////////  busqueda del estado del usuario /////////////////////////////////
                if (req.body.password === undefined) {
                    if (result.estado === 'inhabilitado') {
                        return res.status(500).send({mensaje: 'cuenta inhabilitada', estado : result.estado});
                    }
                    // else if (result.estado === 'pendiente') {
                    //     return res.status(500).send({mensaje: 'pendiente de validacion', estado : result.estado});
                    // }
                    // _busquedaUsuarioModules
                    else if (result.estado === 'habilitado' ||result.estado === 'cambio contraseña' ) {
                                return res.status(200).send({mensaje: 'modulo habilitado',  estado : 'modulo habilitado', nombre: result.nombreCompleto});
                    // } else if (result.estado === 'creacion'){
                    //     return res.status(401).send({message: "falta validacion"}); //////////////// test /////
                    } else {
                        return res.status(500).send({message: "error desconocido"}); //////////////// test /////
                    }
                }
////////////////////////////////////////////////////////////  atenticacion del usuario /////////////////////////////////
                else {
                    // _busquedaUsuarioModules(busquedaUsuario, busquedaScope).then( resultModules => {
                    //     if (resultModules.habilitacionGeneral === 'inhabilitado') {
                    //         return res.status(500).send({mensaje: 'modulo inhabilitado',  estado : 'modulo inhabilitado'});
                    //     }
                    //     else if (resultModules.habilitacionGeneral === 'habilitado') {
                            
                            if (bcrypt.compareSync(req.body.password, result.password)) {
                                // delete resultModules.configuracion.firebaseID;
                                // if(resultModules.configuracion !== undefined)
                                //     if(resultModules.configuracion.firebaseID!== undefined){
                                //         delete resultModules.configuracion.firebaseID;
                                //     }
                                
                                
                                //Modificacion Kevin
                                //const payload = {IDclient: result.identificador, nombreEmpresa: result.identificadorEmpresa};
                                const payload = {IDclient: result.email};
                                //Fin Modificacion Kevin
                                var jwtUser = jwt.sign(payload,global.JWT_SECRET,{expiresIn:'16h'});
            
                                let parameters ={
                                    nombres: result.nombreCompleto,
                                    email: result.email,
                                    tipoCuenta: result.tipoCuenta
                                    // validacion: result.validacion,
                                    // estado : result.estado,
                                    // estadoTienda: result.estadoTienda,
                                    // imagenURL: result.imagenURL,
                                    // identificadorEmpresa: result.identificadorEmpresa
                                };

                                return res.status(200).send({jtoken: jwtUser, parameters: parameters,  version: 'v1.0'});
                            } else {
                                return res.status(401).json({ error: 'incorrect password' });
                            }
                            
                    //     }
                    //     else  {
                    //         return res.status(500).send({mensaje: 'error de modulos',  estado : 'error de modulos'});
                    //     }
                    //     // console.log('modules', resultModules);

                    // }, error=>{
                    //     console.log('error',error);
                    //     return res.status(500).send({mensaje: 'modulo inexistente', estado : 'modulo inexistente'});                            
                    // });


                }


            },
            error =>{
                return res.status(500).send({mensaje:'no existe el usuario'});
            }
            );

}





// function administracionAuth2 (req, res){
//     let user = req.body;
//     console.log(user);

//     if ((req.body.username=== undefined)|| req.body.scope=== undefined ) {
//         return res.status(500).send({message: "falta parametro de usuario"});
//     }
//     let busqueda ;


//     _busquedaEmpresa(req.body.scope).then(
//         result => {


//             console.log('result', result);
//             if (result.status !== 'habilitado') {
//                 return res.status(500).send({message: "error de habilitacion"});
//             }



//             if (req.body.username!== undefined) {
//                 busqueda = req.body.username;
//             }

//             _busquedaUsuarioAdmin(busqueda).then(result => {
//                 console.log('ok', result);

//                 // si no enviaron password solo devuelve el estado del usuario
//                 if (req.body.password === undefined) {
//                     if (result.estado === 'inhabilitado') {
//                         return res.status(500).send({mensaje: 'cuenta inhabilitada', estado : result.estado});
//                     }

//                     // _busquedaUsuarioModules
//                     if (result.estado === 'habilitado') {

//                         let acceso = null;
//                         result.accesos.forEach(accesoModule =>
//                         {
//                             if (accesoModule.scope === req.body.scope)
//                             {
//                                 acceso = accesoModule;
//                             }
//                         });
//                         if (acceso!=null)
//                         {
//                             if(acceso.estado == 'habilitado'){
//                                 return res.status(200).send({mensaje: 'cuenta OK', validacion : acceso.estado});
//                             } 
//                             else if(acceso.estado == 'inhabilitado') {
//                                 return res.status(401).send({mensaje: 'cuenta Error', validacion : acceso.estado});
//                             }
//                             return res.status(401).json({ error: 'incorrect modules' });
//                         } else {
//                             return res.status(200).send({mensaje: 'cuenta pendiente de validacions', validacion : 'falta modulo'});
//                         }
//                     }


//                     return res.status(401).send({mensaje: 'error de validaciones', validacion : 'err'});
//                 }
//                 // siesta pendiente de validacion devuelve el estado
//                 if (result.validacion === 'pendiente'){
//                     return res.status(401).json({ error: 'cuenta pendiente de validacion' , validacion : result.validacion});
//                 }


//                 // || req.body.password=== undefined

//                 if (!bcrypt.compareSync(req.body.password, result.password)) {
//                     return res.status(401).json({ error: 'incorrect password' });
//                 }else {
//                     let parameters ={
//                         nombres: result.nombres,
//                         apellidos: result.apellidos,
//                         estado: result.estado,
//                         validacion : result.validacion
//                     };

//                     let acceso = null;
//                     result.accesos.forEach(accesoModule =>
//                     {
//                         if (accesoModule.scope === req.body.scope)
//                         {
//                             acceso = accesoModule;
//                         }
//                     });

//                     // delete result.password;
//                     // delete result._id;
//                     // delete result.identificador;
//                     if (acceso==null)
//                     {
//                         return res.status(401).json({ error: 'incorrect modules' });
//                     }


//                     const payload = {IDclient: result.identificador, scope: acceso.scope};
//                     var jwtUser = jwt.sign(payload,global.JWT_SECRET,{expiresIn:'16h'});

//                     return res.status(200).send({jtoken: jwtUser, parameters: parameters, module: acceso,  version: 'v1.0'});
//                 }
//             }, reason => {
//                 console.log('error', reason);
//                 return res.status(500).send({mensaje:'usuario no registrado'});
//             });

//         }, error => {


//             return res.status(500).send({mensaje:'problema desconocido'});

//         }
//     );





// }


//
// function administracionAuthIm (req, res){
//     let user = req.body;
//     console.log(user);
//
//     if ((req.body.IMEI=== undefined)|| req.body.password=== undefined || req.body.scope=== undefined ) {
//         return res.status(500).send({message: "falta parametro de usuario"});
//     }
//     let busqueda ;
//
//     if (req.body.username!== undefined) {
//         busqueda = req.body.username;
//     }
//
//     _busquedaUsuarioAdmin(busqueda).then(result => {
//         console.log('ok', result);
//
//         if (!bcrypt.compareSync(req.body.password, result.password)) {
//             return res.status(401).json({ error: 'incorrect password' });
//         }else {
//             let parameters ={
//                 nombres: result.nombres,
//                 apellidos: result.apellidos,
//                 estado: result.estado
//             };
//
//             let acceso = null;
//             result.accesos.forEach(accesoModule =>
//             {
//                if (accesoModule.scope === req.body.scope)
//                {
//                    acceso = accesoModule;
//                }
//             });
//
//             // delete result.password;
//             // delete result._id;
//             // delete result.identificador;
//             if (acceso==null)
//             {
//                 return res.status(401).json({ error: 'incorrect modules' });
//             }
//
//
//             const payload = {IDclient: result.identificador};
//             var jwtUser = jwt.sign(payload,global.JWT_SECRET,{expiresIn:'16h'});
//
//             return res.status(200).send({jtoken: jwtUser, parameters: parameters, module: acceso,  version: 'v1.0'});
//         }
//     }, reason => {
//         console.log('error', reason);
//         return res.status(500).send({mensaje:'usuario no registrado'});
//     });
// }
//

//
// function testAuthMob (req, res){
//     let user = req.body;
//     console.log(user);
//
//     if ((req.body.username=== undefined)|| req.body.scope=== undefined ) {
//         return res.status(500).send({message: "falta parametro de usuario"});
//     }
//     let busqueda ;
//
//     if (req.body.username!== undefined) {
//         busqueda = req.body.username;
//     }
//
//     _busquedaUsuarioCelular(busqueda).then(result => {
//         console.log('ok', result);
//
//         return res.status(200).send({mensaje: 'usuario existente', validacion : result.validacion});
//     }, reason => {
//         console.log('error', reason);
//         return res.status(500).send({mensaje:'usuario no registrado'});
//     });
// }

//
// function setNewPassUsrMob (req, res){
//         let user = req.body;
//         console.log(user);
//
//         if ((req.body.username=== undefined)|| req.body.password=== undefined || req.body.newPassword=== undefined ||
//             req.body.scope=== undefined ) {
//             return res.status(500).send({message: "falta parametro de usuario"});
//         }
//         let busqueda ;
//
//         if (req.body.username!== undefined) {
//             busqueda = req.body.username;
//         }
//
//     _busquedaUsuarioCelular(busqueda).then(result =>  {
//             console.log('ok', result);
//
//             if (req.body.newPassword.length !== 5) {
//                 return res.status(500).send({message: "error en dimensión de clave"});
//             }
//
//             if (!bcrypt.compareSync(req.body.password, result.passwordRapida)) {
//                 return res.status(401).json({ error: 'incorrect password' });
//             }else {
//
//                 let parameters ={
//                     nombres: result.nombres,
//                     apellidos: result.apellidos,
//                     estado: result.estado
//                 };
//
//                 let acceso = null;
//                 result.accesos.forEach(accesoModule =>
//                 {
//                     if (accesoModule.scope === req.body.scope)
//                     {
//                         acceso = accesoModule;
//                     }
//                 });
//
//                 console.log('acceso',acceso);
//                 if (acceso==null)
//                 {
//                     return res.status(401).json({ error: 'incorrect modules' });
//                 }
//
//                 const payload = {IDclient: result.identificador};
//                 var jwtUser = jwt.sign(payload,global.JWT_SECRET,{expiresIn:'16h'});
//
//
//                 const fechaActual = new Date();
                // fechaActual.setTime( fechaActual.getTime() - fechaActual.getTimezoneOffset()*60*1000 );
                // const claveCifrada = await generadorClave(req.body.newPassword);
                // generadorClave(req.body.newPassword).then(
                //     claveCifrada => {
                //         let actualizacionCuenta = {
                //             passwordRapida: claveCifrada,
                //             lastChangePassRapida : fechaActual
                //         } ;

                //         var database = db.get();
                //         var DB = database.db('Administracion3');
                //         var collection = DB.collection('usuarios');
                //         collection.findOneAndUpdate(
                //             {_id: new ObjectID(result._id)},
                //             {$set: actualizacionCuenta},
                //             (err,result)=> {
                //                 if (err) {
                //                     return res.status(500).json({error: err.message});
                //                 }
//                                 if (!result.value) {
//                                     return res.status(404).json({error: 'no actualizado'});
//                                 }
//                                 return res.status(200).send({jtoken: jwtUser, parameters: parameters, module: acceso,  version: 'v1.0'});
//                             });
//
//                     }
//                 );
//             }
//         }, reason => {
//             console.log('error', reason);
//             return res.status(500).send({mensaje:'usuario no registrado'});
//         });
//     }
//
//


function administracionAuthMob (req, res){

    let user = req.body;
    console.log(user);

    if ((req.body.username=== undefined)|| req.body.scope=== undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }
    let busquedaUsuario = req.body.username;
    let busquedaScope =req.body.scope;

    _busquedaEmpresa(busquedaScope).then(
        empresa => {
            console.log('result', empresa);
            if (empresa.status !== 'habilitado') {
                return res.status(500).send({message: "error de habilitacion"});
            }
////////////////////////////////////////////////////////////////////////////////////busqueda del usuario /////////////////////////////////
            // if (req.body.username!== undefined) {
                // busquedaUsuario = req.body.username;
            // }
            _busquedaUsuarioCelular(busquedaUsuario).then(result => {
                console.log('ok', result);
                console.log('password', req.body.password);

////////////////////////////////////////////////////////////  busqueda del estado del usuario /////////////////////////////////
                if (req.body.password === undefined) {
                    console.log('password no definido');
                    if (result.estado === 'inhabilitado') {
                        return res.status(500).send({mensaje: 'cuenta inhabilitada', estado : result.estado});
                    }
                    else if (result.estado === 'pendiente') {
                        return res.status(500).send({mensaje: 'pendiente de validacion', estado : result.estado});
                    }
                    // _busquedaUsuarioModules
                    else if (result.estado === 'habilitado' || result.estado === 'cambio contraseña') {
                        _busquedaUsuarioModules(busquedaUsuario, busquedaScope).then( resultModules => {
                            console.log(resultModules);
                            if (resultModules.habilitacionGeneral === 'inhabilitado') {
                                return res.status(500).send({mensaje: 'modulo inhabilitado',  estado : 'modulo inhabilitado'});
                            }
                            else if (resultModules.habilitacionGeneral === 'habilitado') {
                                return res.status(200).send({mensaje: 'modulo habilitado',  estado : 'modulo habilitado'});
                            }
                            else  {
                                return res.status(500).send({mensaje: 'error de modulos',  estado : 'error de modulos'});
                            }
                            // console.log('modules', resultModules);

                        }, error=>{
                            console.log('error',error);
                            return res.status(200).send({mensaje: 'modulo inexistente', estado : 'modulo inexistente'});                            
                        });
                    } else if (result.estado === 'creacion'){
                        return res.status(401).send({message: "falta validacion"}); //////////////// test /////
                    } else {
                        return res.status(500).send({message: "error desconocido"}); //////////////// test /////
                    }
                }
////////////////////////////////////////////////////////////  atenticacion del usuario /////////////////////////////////
                else {
                    _busquedaUsuarioModules(busquedaUsuario, busquedaScope).then( resultModules => {
                        if (resultModules.habilitacionGeneral === 'inhabilitado') {
                            return res.status(500).send({mensaje: 'modulo inhabilitado',  estado : 'modulo inhabilitado'});
                        }
                        else if (resultModules.habilitacionGeneral === 'habilitado') {
                            
                            if (bcrypt.compareSync(req.body.password, result.passwordRapida)) {
                                // delete resultModules.configuracion.firebaseID;
                                if(resultModules.configuracion !== undefined)
                                    if(resultModules.configuracion.firebaseID!== undefined){
                                        delete resultModules.configuracion.firebaseID;
                                    }

                                const payload = {IDclient: result.identificador, nombreEmpresa: result.identificadorEmpresa, scope: resultModules};
                                var jwtUser = jwt.sign(payload,global.JWT_SECRET,{expiresIn:'16h'});
            
                                let parameters ={
                                    nombres: result.nombreCompleto,
                                    validacion: result.validacion,
                                    estado : result.estado
                                };

                                return res.status(200).send({jtoken: jwtUser, parameters: parameters, module: resultModules,  version: 'v1.0'});
                            } else {
                                return res.status(401).json({ error: 'incorrect password' });
                            }
                            
                        }
                        else  {
                            return res.status(500).send({mensaje: 'error de modulos',  estado : 'error de modulos'});
                        }
                        // console.log('modules', resultModules);

                    }, error=>{
                        console.log('error',error);
                        return res.status(500).send({mensaje: 'modulo inexistente', estado : 'modulo inexistente'});                            
                    });


                }


            }, error =>{
                return res.status(500).send({mensaje:'usuario no registrado'});
            });
        }, error => {
            return res.status(500).send({mensaje:'problema desconocido'});
        }
    );

}


///////////////////////////////////////////////////////////
function administracionAuthMob2 (req, res){
    let user = req.body;
    console.log(user);

    if ((req.body.username=== undefined) || req.body.scope=== undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }
    let busqueda ;


    _busquedaEmpresa(req.body.scope).then(
        result => {


            console.log('result', result);
            if (result.status !== 'habilitado') {
                return res.status(500).send({message: "error de habilitacion"});
            }




            if (req.body.username!== undefined) {
                busqueda = req.body.username;
            }

            _busquedaUsuarioCelular(busqueda).then(result => {
                console.log('ok', result);


                // si no enviaron password solo devuelve el estado del usuario
                if (req.body.password === undefined) {
                    return res.status(200).send({mensaje: 'usuario existente', validacion : result.validacion});
                }

                // siesta pendiente de validacion devuelve el estado
                if (result.validacion === 'pendiente'){
                    return res.status(401).json({ error: 'cuenta pendiente de validacion' , validacion : result.validacion});
                }


                if (!bcrypt.compareSync(req.body.password, result.passwordRapida)) {
                    return res.status(401).json({ error: 'incorrect password' });
                }else {
                    let parameters ={
                        nombres: result.nombreCompleto,
                        // apellidos: result.apellidos,
                        // estado: result.estado
                        validacion: result.validacion
                    };

                    let acceso = null;
                    result.accesos.forEach(accesoModule =>
                    {
                        if (accesoModule.scope === req.body.scope)
                        {
                            acceso = accesoModule;
                            // delete acceso.configuracion.firebaseID;

                        }
                    });

                    // delete result.password;
                    // delete result._id;
                    // delete result.identificador;
                    if (acceso==null)
                    {
                        return res.status(401).json({ error: 'incorrect modules' });
                    }


                    const payload = {IDclient: result.identificador, nombreEmpresa: result.identificadorEmpresa, scope: acceso};
                    // const payload = {usuarioID: result.identificador};
                    var jwtUser = jwt.sign(payload,global.JWT_SECRET,{expiresIn:'16h'});

                    return res.status(200).send({jtoken: jwtUser, parameters: parameters, module: acceso,  version: 'v1.0'});
                }
            }, reason => {
                console.log('error', reason);
                return res.status(500).send({mensaje:'usuario no registrado'});
            });

        }, error => {


            return res.status(500).send({mensaje:'problema desconocido'});

        }
    );
}


///////////////////////////////////////////////////////////
function verifyRefreshToken (req, res){
    let body = req.body;
    console.log(body);

    if ((body.token=== undefined) || body.scope=== undefined ) {
        return res.status(500).send({message: "faltan parametros"});
    }
    let busqueda ;


    _busquedaEmpresa(body.scope).then(
        result => {
            console.log('result', result);
            if (result.status !== 'habilitado') {
                return res.status(500).send({message: "error de habilitacion"});
            }
            
            jwt.verify(body.token, global.JWT_SECRET, function(err, decoded) {
                if(err){
                    return res.status(500).send({mensaje:'token invalido'});
                }
                busqueda = decoded.IDclient;
                console.log(decoded, busqueda);

                _busquedaUsuarioCelular(busqueda).then(result => {
                    console.log('ok', result);

                        let parameters ={
                            nombres: result.nombreCompleto,
                            // apellidos: result.apellidos,
                            // estado: result.estado
                            validacion: result.validacion
                        };

                        let acceso = null;
                        result.accesos.forEach(accesoModule =>
                        {
                            if (accesoModule.scope === body.scope)
                            {
                                acceso = accesoModule;
                                // delete acceso.configuracion.firebaseID;
                            }
                        });

                        // delete result.password;
                        // delete result._id;
                        // delete result.identificador;
                        if (acceso==null)
                        {
                            return res.status(401).json({ error: 'incorrect modules' });
                        }

                        // const payload = {IDclient: result.identificador, scope: acceso};
                        // var jwtUser = jwt.sign(payload,global.JWT_SECRET,{expiresIn:'16h'});

                        const payload = {IDclient: result.identificador, nombreEmpresa: result.identificadorEmpresa ,scope: acceso};
                        var jwtUser = jwt.sign(payload,global.JWT_SECRET,{expiresIn:'16h'});
    
                        let parametros ={
                            nombres: result.nombreCompleto,
                            email:result.email,
                            validacion: result.validacion,
                            estado : result.estado,
                            estadoTienda: result.estadoTienda,
                            imagenURL: result.imagenURL,
                            identificadorEmpresa: result.identificadorEmpresa
 
                        };

                        return res.status(200).send({jtoken: jwtUser, parameters: parametros, module: acceso,  version: 'v1.0'});
                }, reason => {
                    console.log('error', reason);
                    return res.status(500).send({mensaje:'usuario no registrado'});
                });


            });

        }, error => {


            return res.status(500).send({mensaje:'problema desconocido'});

        }
    );
}
//////////////////////////////////////////////////////  FIREBASE ID ///////////////////////////////////////



function registroFirebaseId (req, res){

    if ( req.body.firebaseID=== undefined || req.body.scope=== undefined) {
        return res.status(500).send({message: "falta parametros"});
    }

    let idClient = global.getIDclient(req.headers);
    console.log(idClient);

    let busquedaScope =req.body.scope;

    _busquedaEmpresa(busquedaScope).then(
        result =>{ 
            console.log("empresa encontrada");
            // _busquedaUsuario(idClient).then(
            //     resultClient => {
            _UpdateUsuarioModules(idClient, busquedaScope, 'firebaseID',req.body.firebaseID).then(
                resultModules => {
                    console.log(resultModules);    
                    return res.status(200).send({mensaje: 'id registrado'});

                }, error => {
                    return res.status(500).send({message: "no actualizado"});
                }
            )
            //     }
            // );
        }, error => {
            return res.status(500).send({message: "no actualizado"});
        }

    );



    // let busquedaUsuario = req.body.username;
    // let busquedaScope =req.body.scope;

    // _busquedaEmpresa(busquedaScope).then(


}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function cambioContraseña (req, res){
    let user = req.body;
    console.log(user);

    if ((req.body.username=== undefined)|| req.body.contrasenaAnterior === undefined || req.body.contrasenaNueva === undefined ) {
        return res.status(500).send({message: "falta parametro de usuario"});
    }
    let busquedaUsuario = req.body.username;
    // let busquedaScope = req.body.scope;

    // _busquedaEmpresa(busquedaScope).then(
    //     empresa => {
    //         console.log('result', empresa);
    //         if (empresa.status !== 'habilitado') {
    //             return res.status(500).send({message: "error de habilitacion"});
    //         }
////////////////////////////////////////////////////////////////////////////////////busqueda del usuario /////////////////////////////////
            // if (req.body.username!== undefined) {
                // busquedaUsuario = req.body.username;
            // }
            _busquedaUsuarioAdmin(busquedaUsuario).then( async result  =>  {
                console.log('ok', result);

////////////////////////////////////////////////////////////  busqueda del estado del usuario /////////////////////////////////

                if (result.estado === 'inhabilitado') {
                    return res.status(500).send({mensaje: 'cuenta inhabilitada', estado : result.estado});
                }

                if (!bcrypt.compareSync(req.body.contrasenaAnterior, result.password)){
                    return res.status(401).send({error: "incorrect password"});
                }
                
                if (req.body.contrasenaNueva.length >= 6){

                    // if (resultModules.habilitacionGeneral === 'habilitado') {

                        const claveCifrada = await generadorClave(req.body.contrasenaNueva);

                        let auxActualizacion ={};
                        auxActualizacion.password=  claveCifrada;
                        // auxActualizacion.passwordRapida=  claveCifrada;
                        auxActualizacion.estado=  'habilitado';
                
                        var database = db.get();
                        var DB = database.db(global.getAuthDatabase());
                        var collection = DB.collection('usuarios');
            
                        collection.findOneAndUpdate(
                            {_id: new ObjectID(result._id)},
                            {$set:auxActualizacion},
                            (err,result)=> {
                                if (err) {
                                    return res.status(500).json({error: err.message});
                                }
                                if (!result.value) {
                                    return res.status(404).json({error: 'no actualizado'});
                                }
                                return res.status(200).send({mensaje: 'cambio de clave realizada con exito'});
                            });
            

                    // }

                } else {
                    return res.status(500).send({mensaje:'contraseña insufiente'});
                }

            });
    //     }, error => {
    //         return res.status(500).send({mensaje:'problema desconocido'});
    //     }
    // );
}






////////////////////////////////////////////////////funcionalidades ///////////////////////////////////////

function _busquedaEmpresa(empresa){

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('empresas');

    // var search= {$or: [{identificador: parametro},{email: parametro},{username: parametro}]};


    var search = {
        scope: empresa,
    }


    let parametros = {projection:{
            identificador:1,
            nombre:1,
            status:1,
        }};

    const promesa = new Promise((resolve, reject) => {
        collection.findOne(search, parametros, function (err,result) {
            if(err){
                reject({mensaje:"Error en la peticion de la empresa"});
            }else{
                // console.log('error', result);
                if(!result){
                    reject({mensaje:"error"});
                }else{
                    resolve(result);
                }
            }
        });
    });
    return promesa;

}


////////////////////////////////////////////////////funcionalidades ///////////////////////////////////////

function _busquedaUsuario(parametro){

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

    var search= {$or: [{identificador: parametro},{email: parametro},{username: parametro}]};

    let parametros = {projection:{

            identificador:1,
            nombres:1,
            apellidos:1,
            password:1,            identificadorEmpresa: 1,

            estado:1,
            accesos:1,
        }};

    const promesa = new Promise((resolve, reject) => {
            collection.findOne(search, parametros, function (err,result) {
                if(err){
                    reject({mensaje:"Error en la peticion del usuario"});
                }else{
                    // console.log('busqueda', result);
                    if(!result){
                        reject({mensaje:"error"});
                    }else{
                        resolve(result);
                    }
                }
            });
    });
    return promesa;

}

function _busquedaUsuarioAdmin(parametro){

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

    var search= {$or: [{identificador: parametro},{email: parametro}]};


    let parametros = {projection:{

            identificador:1,
            nombreCompleto:1,
            identificadorEmpresa: 1,
            nombres:1,
            apellidos:1,
            email:1,
            password:1,
            passwordRapida:1,
            accesos:1,
            estado:1,
            estadoTienda:1,
            validacion:1,
            imagenURL: 1,
            tipoCuenta:1,
        }};

    const promesa = new Promise((resolve, reject) => {
            collection.findOne(search, parametros, function (err,result) {
                if(err){
                    reject({mensaje:"Error en la peticion del usuario"});
                }else{
                    console.log('busqueda', result);
                    if(result === null){
                        reject({mensaje: 'error no existe ' })
                    }
                    else if(!result){
                        reject({mensaje:"error"});
                    }else{
                        resolve(result);
                    }
                }
            });
    });
    return promesa;
}

function _busquedaUsuarioCelular(parametro){

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

    var search= {$or: [{identificador: parametro},{email: parametro},{username: parametro}]};


    let parametros = {projection:{

            identificador:1,
            nombreCompleto:1,
            identificadorEmpresa: 1,
            nombres:1,
            apellidos:1,
            email: 1,
            passwordRapida:1,
            accesos:1,
            estado:1,
            validacion:1,
            imagenURL:1,
            estadoTienda: 1

        }};

        console.log(search)
    const promesa = new Promise((resolve, reject) => {
            collection.findOne(search, parametros, function (err,result) {
                if(err){
                    reject({mensaje:"Error en la peticion del usuario"});
                }else{
                    // console.log('busqueda', result);
                    if(!result){
                        reject({mensaje:"error"});
                    }else{
                        resolve(result);
                    }
                }
            });
    });
    return promesa;
}




function _busquedaUsuarioModules(parametro, scope){

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

    var search= {$and: [
        {$or: [{identificador: parametro},{email: parametro},{username: parametro}]},
        {accesos: {$elemMatch: {scope: scope}}}
    ]};
    
    let parametros = {projection:{

            accesos:{ $elemMatch: { scope: scope } },
            // nombres:1,
            // apellidos:1,
            // passwordRapida:1,
            // accesos:1,
            // estado:1,
            // validacion:1,
        }};

    const promesa = new Promise((resolve, reject) => {
            collection.findOne(search, parametros, function (err,result) {
                if(err){
                    reject({mensaje:"Error en la peticion del usuario"});
                }else{
                    // console.log('busqueda', result);
                    if(!result){
                        reject({mensaje:"error"});
                    }else{
                        resolve(result.accesos[0]);
                    }
                }
            });
    });
    return promesa;
}

function _UpdateUsuarioModules(usuario, scope, parametro, actualizacion){

    var database = db.get();
    var DB = database.db(global.getAuthDatabase());
    var collection = DB.collection('usuarios');

    var search= {$and: [
        {$or: [{identificador: usuario},{email: usuario},{username: usuario}]},
        {accesos: {$elemMatch: {scope: scope}}}
    ]};
    
    let parametros = {projection:{
            accesos:{ $elemMatch: { scope: scope } },
        }};

    const promesa = new Promise((resolve, reject) => {
            collection.findOne(search, parametros, function (err,result) {
                if(err){
                    reject({mensaje:"Error en la peticion del usuario"});
                }else{
                    // console.log('busqueda', result);
                    if(!result){
                        reject({mensaje:"error"});
                    }else{

                        console.log('res', result.accesos[0]);

                        search= {
                            _id : new ObjectID(result._id),
                            accesos: result.accesos[0]
                        };

                        let actualizacionParametro = "accesos.$.configuracion."+[parametro];
                        let actualizacionObjeto = {};
                        actualizacionObjeto[actualizacionParametro]= actualizacion

                        let accion = {
                            $set : actualizacionObjeto
                            // {

                                // "accesos.$.configuracion" : {firebaseID : actualizacion}
                            // }
                        }
                        console.log(search);
                        // resolve(accesos);
                        collection.findOneAndUpdate(
                            search, accion,
                            (err)=>{
                                if(err){
                                    reject({mensaje:"Error en la actualizacion del documento", codigoError: 102});
                                }else{
                                    console.log("actualizacion documento correcta");
                                    resolve(usuario);
                                }
                            }
                        );

                    }
                }
            });
    });
    return promesa;
}


////////////////////////////////////////////////////////////////funciones de utilidad //////////////////////////////////

function generadorIdentificador (digitos){
    let caracteres = "0123456789";
    let identificador = "";
    let i;
    for (i=0; i<digitos; i++) identificador +=caracteres.charAt(Math.floor(Math.random()*caracteres.length));

    return identificador;
}


function generadorClave(clave){
    var salt = bcrypt.genSaltSync(13);
    var hasht;

    const promesa = new Promise((resolve, reject) => {
        bcrypt.hash(clave, salt, function(err, hash){
            if(err) throw err;

            bcrypt.compare(clave, hash, function(err, result) {
                if (err) {
                    throw (err);
                }
                console.log(result);
                hasht = hash;
                resolve(hasht);
            });
        });

    });
    return promesa;

}




module.exports = {
    status,
    auth,
    // administracionAuth2,
    administracionAuthMob,
    // testAuthMob,
    // setNewPassUsrMob,
    // administracionAuthIm
    registroFirebaseId,
    verifyRefreshToken,


    cambioContraseña
};

