'use strict'

var db = require('../db');
var ObjectId = require('objectid');
const config = require('../config');

////////////////////////////////////CONEXION CON EL SERVIDOR
db.connect(config.getDB(), function(err) {

    if (err) {
		console.log(err)
    } else {

        let fecha= new Date();
        fecha.setTime(fecha.getTime() - fecha.getTimezoneOffset()*60*1000 ); 
        //console.log(fecha)
    
        let DB = db.get().db(config.getDataBase()).collection(config.getCollCsht());
    
        let search ={$and:[ {fechaRetiro: {$lte: fecha}} , {accion: 'creado'}, {tipo: 'automatico'}]}; 
    
        DB.find(search).toArray(function (err,result) {
            if(err){
                console.log({mensaje:"Error en la peticion"});
                db.close();
            }else{
                if(result.length == 0){
                    console.log('ERROR\n', 'No existen');
                    db.close();
                }else{

                    setCashout(result).then(
                        result =>{
                            console.log('OK\n', result);
                            db.close();
                        },error => {
                            console.log('ERROR\n', error);
                            db.close();
                        }
                    )  
                }
            }
        })
    }
});


async function setCashout (datos){

    console.log(datos)
    
    let DB = db.get().db(config.getDataBase()).collection(config.getCollCsht());
    
    var datosCashout = await Promise.all(datos.map(
            
        function(result) {
            
            console.log('12', result)

            return new Promise((resolve, reject) => {

                let aux={
                    accion: 'cashout'
                }

                let One ={_id: ObjectId(result._id)};

                DB.findOneAndUpdate(One, {$set: aux}, function (err,result) {
                    if(err){
                        reject ({message:"Error al actualizar"});
                    }else{
                        resolve({message:"Actualizacion Exitosa"});
                    }
                }) 
                
            
            })
        }))

    return(datosCashout)
}
