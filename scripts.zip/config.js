'use strict'

module.exports={
    getDB:function(){
        return 'mongodb://dbClickAdmin:clickAdminPass@52.43.113.195:38510/admin';
    },
    getDataBase:function(){
        return "BlueCapital";
    },
    getCollUsrs:function(){
        return 'usuarios';
    },
    getCollInvrsn:function(){
        return 'inversiones';
    },
    getCollCsht:function(){
        return 'cashout';
    },
    
};

